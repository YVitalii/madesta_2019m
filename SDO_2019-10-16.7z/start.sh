echo Запуск сервера АСУ
pwd
cd ./SDO
pwd
sudo supervisor ./bin/www
